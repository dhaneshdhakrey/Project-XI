import React from "react";

const AddCart=React.createContext({
    TotalPrice:0,
    
});
export default AddCart;