import React from "react";
function CollectionController(){
    return(
        <div>
            <h1>CollectionController</h1>
        </div>
    );
}
export default CollectionController;    

