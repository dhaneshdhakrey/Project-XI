import React from "react";

function Load() {
  return (
    gay
  );
}
export default Load;    