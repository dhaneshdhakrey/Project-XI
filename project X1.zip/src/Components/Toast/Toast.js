// import React from 'react';
// import { ToastProvider, useToast, ToastTypes } from './Toast-provider';

// function Toast() {
//   return (
//     <ToastProvider>
//       <ToastExample />
//     </ToastProvider>
//   );
// }

// function ToastExample() {
//   const toast = useToast();

//   return (
//     <div className='Toast mt-[10%]'>
//       <button onClick={() => toast('Simple notification')}>
//         Basic Toast
//       </button>
//       <button onClick={() => toast('order placed successfully!', ToastTypes.SUCCESS)}>
//         Success Toast
//       </button>
//     </div>
//   );
// }

// export default Toast;