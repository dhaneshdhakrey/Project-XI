import React from 'react'

function Ui_Card(props){
    return(
        <React.Fragment>props.children</React.Fragment>
    );
}
export default Ui_Card;