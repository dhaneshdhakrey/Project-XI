function buttons() {
    return (
        <div>
            <p>buttons</p>
        </div>
    );
}